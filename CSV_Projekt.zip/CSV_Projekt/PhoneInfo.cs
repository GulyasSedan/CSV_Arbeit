﻿fausing System;
using System.Collections.Generic;
using System.Text;

namespace CSV_Projekt
{
    class PhoneInfo
    {
        private int _Number;
        private string _Name;
        private string _Gender;

        public string GetGender()
        {
            return _Gender;
        }
        public void SetGender(string Gender)
        {
            _Gender = Gender;
        }
        public string GetName()
        {
            return _Name;
        }
        
        public int GetNumber()
        {
            return _Number;
        }
        public void SetName(string Name)
        {
            _Name = Name;
        }
        public void SetNumber(int Number)
        {
            _Number = Number;
        }
    }
}
