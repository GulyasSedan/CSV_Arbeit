﻿using System.IO;
using System;
using System.Text;

namespace CSV_Projekt
{
    class Program
    {
        static void Main(string[] args)
        {
            int bookSize = File.ReadAllLines("Book1.csv", Encoding.Default).Length; //Länge der Lines (im CSV) wird gezählt und gespeichert ("bookSize")

            Console.WriteLine("Projekt: Einlesen von Daten aus einer CSV Daten");
            // Das einlesen Der CSV Datei
            string[] input = File.ReadAllLines("Book1.csv", Encoding.Default)
            PhoneInfo[] info = new PhoneInfo[bookSize];
            string[] container;
            for (int i = 0; i <= bookSize; i++)
            {
                container = input[i].Split(';');
                info.SetGender(container[0]);
            }
        }
    }
}
