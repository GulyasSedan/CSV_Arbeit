﻿using System.IO;
using System;
using System.Text;

namespace CSV_Projekt
{
    class Program
    {
        static void PrintBook(PhoneInfo[] info, int bookSize)
        {
            Console.Clear();
            for (int i = 0; i < bookSize; i++)
            {
                Console.WriteLine(info[i].GetNumber() + " - " + info[i].GetName());
            }
            Console.WriteLine("\nDrücken Sie eine beliebige Taste um zum Menü zurückzukehren ...");
            Console.ReadKey();
        }
        static void PrintGenderBook(PhoneInfo[] info, int bookSize, string gender)
        {
            Console.Clear();
            for (int i = 0; i < bookSize; i++)
            {
                if (gender == info[i].GetGender())
                {
                    Console.WriteLine(info[i].GetNumber() + " - " + info[i].GetName());
                }
            }
            Console.WriteLine("\nDrücken Sie eine beliebige Taste um zum Menü zurückzukehren ...");
            Console.ReadKey();
        }
        static void Main(string[] args)
        {
            int bookSize = File.ReadAllLines("Book1.csv", Encoding.Default).Length; //Länge der Lines (im CSV) wird gezählt und gespeichert ("bookSize")

            Console.WriteLine("Projekt: Telefonbuch\nEinlesen von Daten aus einer CSV Datei\n");
            // Das einlesen Der CSV Datei
            string[] csvRaw = File.ReadAllLines("Book1.csv", Encoding.Default);
            PhoneInfo[] info = new PhoneInfo[bookSize];
            string[] csvData = new string[3];
            for (int i = 0; i < bookSize; i++)
            {
                info[i] = new PhoneInfo();
                csvData = csvRaw[i].Split(";");
                info[i].SetName(csvData[0]);
                info[i].SetNumber(csvData[1]);
                info[i].SetGender(csvData[2]);
            }
            bool ending = false;
            Console.WriteLine("\nDrücken Sie eine beliebige Taste ...");
            Console.ReadKey();

            while (!ending)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("Bitte Aktion wählen!\n1 - Telefonbuch ausgeben\n2 - Filter auf weibliche Nummern\n3 - Filter auf männliche Nummern\n4 - Ende\n-->");
                string input = Console.ReadLine();
                Console.ForegroundColor = ConsoleColor.White;
                switch (input)
                {
                    case "1":
                        PrintBook(info, bookSize);
                        break;
                    case "2":
                        PrintGenderBook(info, bookSize, "F");
                        break;
                    case "3":
                        PrintGenderBook(info, bookSize, "M");
                        break;
                    case "4":
                        ending = true;
                        break;
                    default:
                        Console.WriteLine("Eingabe ungültig!\nBitte versuchen Sie es erneut.");
                        Console.ReadKey();
                        break;
                }
            }
        }
    }
}
